from scphere.util.data import prepare_data
