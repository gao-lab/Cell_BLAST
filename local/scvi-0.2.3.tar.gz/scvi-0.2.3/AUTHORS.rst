=======
Credits
=======

* Romain Lopez <romain_lopez@berkeley.edu>
* Jeffrey Regier <jregier@eecs.berkeley.edu>
* Maxime Langevin <maxime.langevin@polytechnique.edu>
* Edouard Mehlman <edouard.mehlman@polytechnique.edu>
* Yining Liu <lyining@berkeley.edu>
