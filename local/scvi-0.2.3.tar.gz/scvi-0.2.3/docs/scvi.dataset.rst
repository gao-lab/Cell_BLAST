scvi.dataset package
====================

Submodules
----------

scvi.dataset.anndata module
---------------------------

.. automodule:: scvi.dataset.anndata
    :members:
    :undoc-members:
    :show-inheritance:

scvi.dataset.brain\_large module
--------------------------------

.. automodule:: scvi.dataset.brain_large
    :members:
    :undoc-members:
    :show-inheritance:

scvi.dataset.cite\_seq module
-----------------------------

.. automodule:: scvi.dataset.cite_seq
    :members:
    :undoc-members:
    :show-inheritance:

scvi.dataset.cortex module
--------------------------

.. automodule:: scvi.dataset.cortex
    :members:
    :undoc-members:
    :show-inheritance:

scvi.dataset.csv module
-----------------------

.. automodule:: scvi.dataset.csv
    :members:
    :undoc-members:
    :show-inheritance:

scvi.dataset.dataset module
---------------------------

.. automodule:: scvi.dataset.dataset
    :members:
    :undoc-members:
    :show-inheritance:

scvi.dataset.dataset10X module
------------------------------

.. automodule:: scvi.dataset.dataset10X
    :members:
    :undoc-members:
    :show-inheritance:

scvi.dataset.hemato module
--------------------------

.. automodule:: scvi.dataset.hemato
    :members:
    :undoc-members:
    :show-inheritance:

scvi.dataset.loom module
------------------------

.. automodule:: scvi.dataset.loom
    :members:
    :undoc-members:
    :show-inheritance:

scvi.dataset.pbmc module
------------------------

.. automodule:: scvi.dataset.pbmc
    :members:
    :undoc-members:
    :show-inheritance:

scvi.dataset.seqfish module
---------------------------

.. automodule:: scvi.dataset.seqfish
    :members:
    :undoc-members:
    :show-inheritance:

scvi.dataset.smfish module
--------------------------

.. automodule:: scvi.dataset.smfish
    :members:
    :undoc-members:
    :show-inheritance:

scvi.dataset.synthetic module
-----------------------------

.. automodule:: scvi.dataset.synthetic
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: scvi.dataset
    :members:
    :undoc-members:
    :show-inheritance:
