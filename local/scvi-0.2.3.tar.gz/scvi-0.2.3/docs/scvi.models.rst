scvi.models package
===================

Submodules
----------

scvi.models.classifier module
-----------------------------

.. automodule:: scvi.models.classifier
    :members:
    :undoc-members:
    :show-inheritance:

scvi.models.log\_likelihood module
----------------------------------

.. automodule:: scvi.models.log_likelihood
    :members:
    :undoc-members:
    :show-inheritance:

scvi.models.modules module
--------------------------

.. automodule:: scvi.models.modules
    :members:
    :undoc-members:
    :show-inheritance:

scvi.models.scanvi module
-------------------------

.. automodule:: scvi.models.scanvi
    :members:
    :undoc-members:
    :show-inheritance:

scvi.models.utils module
------------------------

.. automodule:: scvi.models.utils
    :members:
    :undoc-members:
    :show-inheritance:

scvi.models.vae module
----------------------

.. automodule:: scvi.models.vae
    :members:
    :undoc-members:
    :show-inheritance:

scvi.models.vae\_fish module
----------------------------

.. automodule:: scvi.models.vae_fish
    :members:
    :undoc-members:
    :show-inheritance:

scvi.models.vaec module
-----------------------

.. automodule:: scvi.models.vaec
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: scvi.models
    :members:
    :undoc-members:
    :show-inheritance:
