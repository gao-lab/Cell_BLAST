scvi package
============

Subpackages
-----------

.. toctree::

    scvi.dataset
    scvi.inference
    scvi.models

Submodules
----------

scvi.benchmark module
---------------------

.. automodule:: scvi.benchmark
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: scvi
    :members:
    :undoc-members:
    :show-inheritance:
