scvi.inference package
======================

Submodules
----------

scvi.inference.annotation module
--------------------------------

.. automodule:: scvi.inference.annotation
    :members:
    :undoc-members:
    :show-inheritance:

scvi.inference.experimental\_inference module
---------------------------------------------

.. automodule:: scvi.inference.experimental_inference
    :members:
    :undoc-members:
    :show-inheritance:

scvi.inference.inference module
-------------------------------

.. automodule:: scvi.inference.inference
    :members:
    :undoc-members:
    :show-inheritance:

scvi.inference.posterior module
-------------------------------

.. automodule:: scvi.inference.posterior
    :members:
    :undoc-members:
    :show-inheritance:

scvi.inference.trainer module
-----------------------------

.. automodule:: scvi.inference.trainer
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: scvi.inference
    :members:
    :undoc-members:
    :show-inheritance:
