from setuptools import setup

setup(
    name='DCA_modpp',
    version='0.2.2',
    description='Count autoencoder for scRNA-seq denoising',
    author='Gokcen Eraslan',
    author_email="gokcen.eraslan@gmail.com",
    packages=['dca_modpp'],
    install_requires=['numpy>=1.7',
                      'keras>=2.0.8',
                      'h5py',
                      'six>=1.10.0',
                      'scikit-learn',
                      'scanpy',
                      'kopt',
                      'pandas' #for preprocessing
                      ],
    url='https://github.com/theislab/dca',
    entry_points={
        'console_scripts': [
            'dca_modpp = dca_modpp.__main__:main'
    ]},
    license='Apache License 2.0',
    classifiers=['License :: OSI Approved :: Apache Software License',
                'Topic :: Scientific/Engineering :: Artificial Intelligence',
                 'Programming Language :: Python :: 3.5'],
)
